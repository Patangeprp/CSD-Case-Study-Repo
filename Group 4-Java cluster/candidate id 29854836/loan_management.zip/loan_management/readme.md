loan management system:

Customer Management:

Add new customers:
View customer details
Remove customers
Loan Management:

Add new loan accounts:
View loan details
Update loan information
Remove loan accounts
Payment Management:

Record loan payments:
Calculate interest
View payment history for a loan

Technologies Used
Java
MySQL
JDBC (Java Database Connectivity)

Setup
Database Setup:

Create a MySQL database named loan_management.
Execute the SQL script provided in db-setup.sql to create the necessary tables (customers, loans, payments).
Configure Database Connection:

Update the DatabaseConnection.java file with your MySQL database URL, username, and password.
Run the Application:

Compile and run the Main.java file to start the application.
Follow the on-screen instructions to interact with the loan management system.
Database Schema

Customers Table:
customer_id (Primary Key)
customer_name
Loans Table
loan_id (Primary Key)
customer_id (Foreign Key referencing customers.customer_id)
loan_amount
interest_rate
start_date
end_date
status (Active, Closed)

Payments Table:
payment_id (Primary Key)
loan_id (Foreign Key referencing loans.loan_id)
payment_amount
payment_date

Usage

Adding a Customer:
Enter option 1 from the menu, then enter the customer's name.

Viewing Customer Details:
Enter option 2 from the menu, then enter the customer ID.

Removing a Customer:
Enter option 3 from the menu, then enter the customer ID.

Adding a New Loan:
Enter option 3 from the menu, then follow the prompts to enter loan details.

Recording Loan Payment:
Enter option 7 from the menu, then follow the prompts to record a payment for a loan.

Calculating Interest:
Enter option 8 from the menu, then enter the loan ID to calculate interest.

Viewing Payment History:
Enter option 9 from the menu, then enter the loan ID to view payment history.

Exiting the Application:
Enter option 0 from the menu to exit the application.